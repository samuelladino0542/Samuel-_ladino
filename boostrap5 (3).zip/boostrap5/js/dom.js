console.log("Entramos");

var items = document.getElementsByClassName("item");
var cantidad = items.length;
console.log("cantidad de listas" + cantidad);

//crear nuevos elementos
//document.createElement(nombrreDelElemento)
var div = document.createElement("div");

div; 

div.innerText = "Aprendiendo JavaScript";

var divUno = document.getElementById("uno");

divUno.appendChild(div);

var lista = document.getElementById("lista");

var hijo=document.createElement("li");
hijo.innerText = "li nuevo";
lista.appendChild(hijo);

var par=document.getElementById('dos').style.color = '#FF0033';

var par=document.getElementById('lista').style.color = '#00FF33';

